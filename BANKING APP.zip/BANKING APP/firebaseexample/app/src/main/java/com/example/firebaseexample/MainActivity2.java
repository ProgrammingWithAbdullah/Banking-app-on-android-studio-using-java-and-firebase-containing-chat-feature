// MainActivity2.java
package com.example.firebaseexample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity2 extends AppCompatActivity {

    private Button showBalanceBtn;
    private Button feedbackBtn;
    private TextView balanceTextView;
    private DatabaseReference bankBalanceRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        showBalanceBtn = findViewById(R.id.show_balance);
        feedbackBtn = findViewById(R.id.feedback);
        balanceTextView = findViewById(R.id.show_balance);

        // Get the reference to 'Bank Balance' node
        bankBalanceRef = FirebaseDatabase.getInstance().getReference().child("Bank Balance");

        showBalanceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBankBalance();
            }
        });

        feedbackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFeedbackActivity();
            }
        });
    }

    private void showBankBalance() {
        String key = bankBalanceRef.push().getKey();

        bankBalanceRef.child(key).setValue("9999");

        Toast.makeText(this, "Your Bank Balance is 9999", Toast.LENGTH_SHORT).show();

        // Display the value on the screen
        balanceTextView.setText("Bank Balance : 9999");
    }

    private void openFeedbackActivity() {
        // Start FeedbackActivity when the "Feedback" button is pressed
        Intent intent = new Intent(MainActivity2.this, Feedback.class);
        startActivity(intent);
    }
}
