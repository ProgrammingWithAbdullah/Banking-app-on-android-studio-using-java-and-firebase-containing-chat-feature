// FeedbackActivity.java
package com.example.firebaseexample;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Feedback extends AppCompatActivity {

    private EditText feedbackEditText;
    private Button submitBtn;
    private DatabaseReference feedbackDatabaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feedback);

        feedbackEditText = findViewById(R.id.commentbox);
        submitBtn = findViewById(R.id.submitbtn);

        // Get the reference to 'Feedback' node
        feedbackDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Feedback");

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitFeedback();
            }
        });
    }

    private void submitFeedback() {
        String userFeedback = feedbackEditText.getText().toString();

        // Check if the feedback is not empty
        if (!userFeedback.isEmpty()) {
            // Create a new child under 'Feedback' with a generated key
            String key = feedbackDatabaseRef.push().getKey();

            // Set the user's feedback for the new child
            feedbackDatabaseRef.child(key).setValue(userFeedback);

            // Display a message
            Toast.makeText(this, "Feedback Entered. Thank You for Feedback", Toast.LENGTH_SHORT).show();

            // Clear the EditText
            feedbackEditText.getText().clear();
        } else {
            // Display an error message if the feedback is empty
            Toast.makeText(this, "Please enter your feedback", Toast.LENGTH_SHORT).show();
        }
    }
}
