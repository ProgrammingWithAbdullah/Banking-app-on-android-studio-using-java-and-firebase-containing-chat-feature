package com.example.firebaseexample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button Registerbtn;
    private Button Loginbtn;
    private DatabaseReference rootDatabaseRef;
    private DatabaseReference rootDatabaseRef2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        Registerbtn = findViewById(R.id.Registerbtn);
        Loginbtn = findViewById(R.id.Loginbtn);
        ImageButton whatsappButton = findViewById(R.id.whatsappbtn);

        // Get the reference to the 'User' and 'Password' nodes
        rootDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Username");
        rootDatabaseRef2 = FirebaseDatabase.getInstance().getReference().child("Password");

        Registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        Loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        whatsappButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When the button is clicked, start MainActivity3
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(intent);
            }
        });
    }

    private void registerUser() {
        String data = username.getText().toString();
        String data2 = password.getText().toString();

        // Generate a unique key for each entry
        String key1 = rootDatabaseRef.push().getKey();
        String key2 = rootDatabaseRef2.push().getKey();

        // Create references to the generated child keys under the 'User' node
        DatabaseReference child1Ref = rootDatabaseRef.child(key1);
        DatabaseReference child2Ref = rootDatabaseRef2.child(key2);

        // Set values for each child
        child1Ref.setValue(data + " for Child1");
        child2Ref.setValue(data2 + " for Child2");
    }

    private void loginUser() {
        final String enteredUsername = username.getText().toString();
        final String enteredPassword = password.getText().toString();

        rootDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Iterate through all children under 'User' node
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    String storedUsername = userSnapshot.getValue(String.class);

                    if (storedUsername != null && storedUsername.equals(enteredUsername)) {
                        // Username found, now check password
                        checkPassword(userSnapshot.getKey(), enteredPassword);
                        return;
                    }
                }
                navigateToNextActivity();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void checkPassword(final String userId, final String enteredPassword) {
        rootDatabaseRef2.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String storedPassword = dataSnapshot.getValue(String.class);

                if (storedPassword != null && storedPassword.equals(enteredPassword)) {
                    // Password match, navigate to the next activity
                    showMessage("Logged in");
                    navigateToNextActivity();
                } else {
                    navigateToNextActivity();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void navigateToNextActivity() {
        showMessage("Logged in");
        Intent intent = new Intent(MainActivity.this,MainActivity2.class);
        startActivity(intent);
        // Finish the current activity to prevent going back
        finish();
    }

    private void showMessage(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
